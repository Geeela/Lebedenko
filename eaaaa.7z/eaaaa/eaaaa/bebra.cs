﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eaaaa
{
    public class Joe
    {
            private int k;
            public int K
            {
                get { return k; }
                set
                {
                    for (int i = 0; i < 10; i++)
                    {
                        k=value;
                    }
                }
            }
    }
}
