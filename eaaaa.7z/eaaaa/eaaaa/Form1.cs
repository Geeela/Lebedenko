﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace eaaaa
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // данные для первого графика
            double a = 0.3;
            double b = 0.5;
            double h = 0.1, x, y;
            this.chart1.Series[0].Points.Clear();
            x = a;
            while (x <= b)
            {
                y = Math.Pow(x, 3);
                this.chart1.Series[0].Points.AddXY(x, y);
                x += h;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //данные для второго графика
            double a = 0.3;
            double b = 0.5;
            double h = 0.1, x, y;
            this.chart1.Series[1].Points.Clear();
            x = a;
            while (x <= b)
            {
                y = (3 * Math.Pow(x, 2)) - (6 * x) + 2;
                this.chart1.Series[1].Points.AddXY(x, y);
                x += h;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            frm2.Show();
            this.Hide();
        }
    }
}
